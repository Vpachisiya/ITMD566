package com.vaishali.web;

import java.io.*;



public class Main {

 

       public static void main(String args[]) {

 

            try {

                Runtime rt = Runtime.getRuntime();

                //Process pr = rt.exec("cmd /c dir");

                Process pr = rt.exec("curl --insecure -o C:/Users/vaish/workspace/WebProj/src/com/vaishali/web/json_parser.java https://maps.googleapis.com/maps/api/geocode/json?address=2901+South+King+Drive+chicago+IL&key=AIzaSyAopTfRYS29xraFdNTBfUkYR7nKk1II_SQ 2> C:/Users/vaish/workspace/WebProj/src/com/vaishali/web/details.txt");

 
                pr = rt.exec("grep lat C:/Users/vaish/workspace/WebProj/src/com/vaishali/web/json_parser.java");
                BufferedReader input = new BufferedReader(new InputStreamReader(pr.getInputStream()));

 

                String line=null;

 

                while((line=input.readLine()) != null) {

                    System.out.println(line);
break;
                }
                
                pr = rt.exec("grep lng C:/Users/vaish/workspace/WebProj/src/com/vaishali/web/json_parser.java");
                
                BufferedReader input_1 = new BufferedReader(new InputStreamReader(pr.getInputStream()));

                

                String line_1=null;

 

                while((line_1=input_1.readLine()) != null) {

                    System.out.println(line_1);
break;
                }


                int exitVal = pr.waitFor();

                System.out.println("Exited with error code "+exitVal);

 

            } catch(Exception e) {

                System.out.println(e.toString());

                e.printStackTrace();

            }

        }
}