package com.vaishali.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ProcessCustomerDataRequest
 */
public class ProcessCustomerDataRequest extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcessCustomerDataRequest() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		HttpSession session=request.getSession(false);
		
		String name = (String)session.getAttribute("customer_name");
		String ssn = (String)session.getAttribute("customer_ssn");
		String zipcode = (String)session.getAttribute("zipcode");
		String email = (String)session.getAttribute("email");
		String address = (String)session.getAttribute("address");
		String city = (String)session.getAttribute("city");
		String state = (String)session.getAttribute("state");
		String latitude = (String)session.getAttribute("latitude");
		String longitude = (String)session.getAttribute("longitude");
		PrintWriter out = response.getWriter();
        
		out.println("<html>");
        out.println("<body bgcolor=\"#FFAAAA\">");
        out.println("<head>");

        out.println("<h1 align = center> Customer Information </h1>");
        out.println("</head>");
        out.println("<body>");
		
		out.println("<table align = center><tr><td><font color=802815   size=5> Name : </font> ");
		out.println("<td>"+name+"</td></tr>");
		
		out.println("<tr><td>");
		out.println("<font color=802815   size=5>SSN : </font>");
		out.println("</td><td>");
		out.println(ssn);
		out.println("</td></tr>");
	
		
		out.println("<tr><td>");
		out.println("<font color=802815   size=5>Zipcode : </font>");
		out.println("</td><td>");
		out.println(zipcode);
		out.println("</td></tr>");
		
		out.println("<tr><td>");
		out.println("<font color=802815   size=5>Email : </font>");
		out.println("</td><td>");
		out.println(email);
		out.println("</td></tr>");
		
		out.println("<tr><td>");
		out.println("<font color=802815   size=5>Address : </font>");
		out.println("</td><td>");
		out.println(address);
		out.println("</td></tr>");
		
		out.println("<tr><td>");
		out.println("<font color=802815   size=5>Latitude : </font>");
		out.println("</td><td>");
		out.println(latitude);
		out.println("</td></tr>");
		
		out.println("<tr><td>");
		out.println("<font color=802815   size=5>Longitude : </font>");
		out.println("</td><td>");
		out.println(longitude);
		out.println("</td></tr>");
		
		out.println("<tr><td>");
		out.println("<font color=802815   size=5>City : </font>");
		out.println("</td><td>");
		out.println(city);
		out.println("</td></tr>");
		
		out.println("<tr><td>");
		out.println("<font color=802815   size=5>State : </font>");
		out.println("</td><td>");
		out.println(state);
		out.println("</td></tr>");

		out.println("</table>");
		out.println("</BR>");
		out.println("</BR>");
		out.println("</BR>");
		out.println("</BR>");
		out.println("</BR>");
		out.println("<center><font color=802815   size=4>Thank You for Registration </font></center>");
		
		out.println("</body>");
		out.println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
