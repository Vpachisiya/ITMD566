package com.vaishali.web;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;


public class ValidateEmailAndZipCode {
    @NotEmpty
    @Email
    private String email;
     
    @NotEmpty(message = "Please enter your zipcode.")
    @Size(min = 5, max = 5, message = "Your zipcode must be 5 digits")
    private String zipcode;
 
    public String getEmail() {
        return email;
    }
 
    public void setEmail(String email) {
        this.email = email;
    }
 
    public String getZipcode() {
        return zipcode;
    }
 
    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }
}
