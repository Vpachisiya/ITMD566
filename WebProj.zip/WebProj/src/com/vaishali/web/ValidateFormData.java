package com.vaishali.web;
import java.util.regex.*;
import java.io.BufferedReader;
//import javax.validation.constraints;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ValidateFormData
 */
public class ValidateFormData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateFormData() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		boolean flag = true;
		
		HttpSession sess=request.getSession();
		
		String name = request.getParameter("customer_name");
		String ssn = request.getParameter("customer_ssn");
		String zipcode = request.getParameter("zipcode");
		String email = request.getParameter("email");
//		session.setAttribute
		String address = request.getParameter("address");
		String city = request.getParameter("city");
		String state = request.getParameter("state");

		//PrintWriter out = response.getWriter();
		final Pattern VALID_EMAIL_ADDRESS_REGEX = 
				Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

		
		Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(email);
		 
		final Pattern VALID_ZIPCODE_REGEX = 
				Pattern.compile("^[0-9][0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]$", Pattern.CASE_INSENSITIVE);
		
		Matcher matcher_zipcode = VALID_ZIPCODE_REGEX.matcher(zipcode);
		     
         if(zipcode==null || zipcode.equals("") || !matcher_zipcode.find()){
            request.setAttribute("ZipcodeErrorMessage", "Invalid Zipcode");
            flag=false;
        }
        
        if(email==null || email.equals("") || !matcher.find()){
            request.setAttribute("EmailErrorMessage", "Invalid Email");
            flag=false;
        }      
 
        String url = "https://maps.googleapis.com/maps/api/geocode/json?address=";
    	String key = "&key=AIzaSyAopTfRYS29xraFdNTBfUkYR7nKk1II_SQ";
    	String new_addr = address.replaceAll(" ", "+");
    	
    	new_addr = new_addr + "+" + city + "+" + state + key; 
    	new_addr = url + new_addr;
    	
    	String latitude = getGeoCode(new_addr, "lat");
    	String longitude = getGeoCode(new_addr, "lng");
    	String arr_1[] = latitude.split(":");
    	String arr_2[] = longitude.split(":");
    	
        if(!flag){
            request.getRequestDispatcher("/GetFormData.jsp").forward(request, response);
        }
        else {
            sess.setAttribute("customer_name", name);
            sess.setAttribute("customer_ssn", ssn);
            sess.setAttribute("zipcode", zipcode);
            sess.setAttribute("email", email);
            sess.setAttribute("address", address);
            sess.setAttribute("city", city);
            sess.setAttribute("longitude", arr_2[1]);
            sess.setAttribute("latitude", arr_1[1]);
            sess.setAttribute("state", state);
            request.getRequestDispatcher("/ProcessCustomerDataRequest").forward(request, response);
        }
        
         //out.println(""+no);       
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	protected String getGeoCode(String url , String whichPoint)
	{
	  try {

          Runtime rt = Runtime.getRuntime();

          //Process pr = rt.exec("cmd /c dir");

          Process pr = rt.exec("curl --insecure -o C:/Users/vaish/workspace/WebProj/src/com/vaishali/web/json_parser.java "+url+" 2> C:/Users/vaish/workspace/WebProj/src/com/vaishali/web/details.txt");


          pr = rt.exec("grep "+ whichPoint +" C:/Users/vaish/workspace/WebProj/src/com/vaishali/web/json_parser.java");
          BufferedReader input = new BufferedReader(new InputStreamReader(pr.getInputStream()));



          String line=null;



          while((line=input.readLine()) != null) {

              return line;
          }
          
          int exitVal = pr.waitFor();

          System.out.println("Exited with error code "+exitVal);



      } catch(Exception e) {

          System.out.println(e.toString());

          e.printStackTrace();

      }
	  
	  return null;
}
}
