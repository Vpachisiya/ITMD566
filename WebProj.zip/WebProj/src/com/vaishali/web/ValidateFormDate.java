package com.vaishali.web;
import java.io.*;
//import javax.validation.constraints;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ValidateFormData
 */
public class ValidateFormData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateFormData() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession sess=request.getSession();
		
		String name = request.getParameter("customer_name");
		String ssn = request.getParameter("customer_ssn");
		String zipcode = request.getParameter("zipcode");
		String email = request.getParameter("email");
//		session.setAttribute
		String address = request.getParameter("address");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		PrintWriter out = response.getWriter();
/*		
		ValidateEmailAndZipCode email_zip_validator = new ValidateEmailAndZipCode();
		     
         if(zipcode==null || zipcode.equals("") || !email_zip_validator.validateZipcode(zipcode)){
            request.setAttribute("ZipcodeErrorMessage", "Invalid Zipcode");
            flag=false;
        }
        
        if(email==null || email.equals("") || !email_zip_validator.validateEmail(email)){
            request.setAttribute("EmailErrorMessage", "Invalid Email");
            flag=false;
        }
  */      
 
        
        if(!flag){
            request.getRequestDispatcher("/GetFormData.jsp").forward(request, response);
        }
        else {
            sess.setAttribute("customer_name", name);
            sess.setAttribute("customer_ssn", customer_ssn);
            sess.setAttribute("zipcode", zipcode);
            sess.setAttribute("email", email);
            sess.setAttribute("address", address);
            sess.setAttribute("city", city);
            sess.setAttribute("state", state);
            request.getRequestDispatcher("/ProcessCustomerDataRequest.jsp").forward(request, response);
        }
        
         out.println(""+no);
         
		out.print(name);
		out.print("\n");
		out.print(ssn);
		out.print("<BR>");
		out.print(zipcode);
		out.print("</BR>");
		out.print(email);
		out.print("</BR>");
		out.print(address);
		out.print("</BR>");
		out.print(city);
		out.print("</BR>");
		out.print(state);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
