{
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "2951",
               "short_name" : "2951",
               "types" : [ "street_number" ]
            },
            {
               "long_name" : "South King Drive",
               "short_name" : "S King Dr",
               "types" : [ "route" ]
            },
            {
               "long_name" : "South Side",
               "short_name" : "South Side",
               "types" : [ "neighborhood", "political" ]
            },
            {
               "long_name" : "Chicago",
               "short_name" : "Chicago",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Cook County",
               "short_name" : "Cook County",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Illinois",
               "short_name" : "IL",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "United States",
               "short_name" : "US",
               "types" : [ "country", "political" ]
            },
            {
               "long_name" : "60616",
               "short_name" : "60616",
               "types" : [ "postal_code" ]
            }
         ],
         "formatted_address" : "2951 S King Dr, Chicago, IL 60616, USA",
         "geometry" : {
            "location" : {
               "lat" : 41.8403892,
               "lng" : -87.6163897
            },
            "location_type" : "ROOFTOP",
            "viewport" : {
               "northeast" : {
                  "lat" : 41.8417381802915,
                  "lng" : -87.6150407197085
               },
               "southwest" : {
                  "lat" : 41.8390402197085,
                  "lng" : -87.61773868029151
               }
            }
         },
         "place_id" : "ChIJmXVGgYkrDogRj4uxqWQOJlk",
         "types" : [ "street_address" ]
      }
   ],
   "status" : "OK"
}
