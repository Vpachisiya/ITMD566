/*
 * A simple Java class to provide functionality similar to Wget.
 *
 * Note: Could also strip out all of the html w/ jtidy.
 */
package com.vaishali.web;
import java.io.*;
import java.net.*;

public class JGit
{

  @SuppressWarnings("deprecation")
public static void main(String[] args)
  {
/*
    if ( (args.length != 1) )
    {
      System.err.println( "\nUsage: java JGet [urlToGet]" );
      System.exit(1);
    }
*/
	  String city = "Chicago";
	  String state = "IL";
	  String address = "2901 South King Drive";
    //String url = "https://www.msn.com/en-us/news/us/missing-pregnant-woman-found-dead-in-national-forest-in-minnesota/ar-BBJhNEi?li=BBnb4R7";

	String url = "https://maps.googleapis.com/maps/api/geocode/json?address=";
	String key = "&key=AIzaSyAZQq-SGxsdJT7Ms2y0vRwkp-ud7uHENd4";
	String new_addr = address.replaceAll(" ", "+");
	new_addr = new_addr + "+" + city + "+" + state + key; 
	new_addr = url + new_addr;
	
    URL u;
    InputStream is = null;
    DataInputStream dis;
    String s;

    try
    {
    	System.out.println(new_addr);
      u = new URL(new_addr);
      is = u.openStream();
      //bis = new DataInputStream(new BufferedInputStream(is));
      BufferedInputStream bis = new BufferedInputStream(is);
      while( bis.available() > 0 ){             	
          System.out.print((char)bis.read());
      }
      
      
/*
      while ((s = bis.readUTF()) != null)
      {
        System.out.print(s);
      }
      */
    }
    catch (MalformedURLException mue)
    {
      System.err.println("Ouch - a MalformedURLException happened.");
      mue.printStackTrace();
      System.exit(2);
    }
    catch (IOException ioe)
    {
      System.err.println("Oops- an IOException happened.");
      ioe.printStackTrace();
      System.exit(3);
    }
    finally
    {
      try
      {
        is.close();
      }
      catch (IOException ioe)
      {
      }
    }

  }

}