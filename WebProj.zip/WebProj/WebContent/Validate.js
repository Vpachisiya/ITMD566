function Validate(){
	
	document.getElementById("name_error").innerHTML = "";
	document.getElementById("address_error").innerHTML = "";
	document.getElementById("ssn_error").innerHTML = "";
	document.getElementById("city_error").innerHTML = "";
	document.getElementById("state_error").innerHTML =  "";
	document.getElementById("zipcode_error").innerHTML =  "";
	document.getElementById("email_error").innerHTML = "";
	
	var username = document.getElementById("name").value;
	var name_len = username.length;
	
	var address = document.getElementById("address").value;
	var address_len = address.length;

	var ssn = document.getElementById("ssn").value;
	var ssn_len = ssn.length;
	var isSSNValid = /^\d\d\d-\d\d-\d\d\d\d$/.test(ssn);
	
	var city = document.getElementById("city").value;
	var city_len = city.length;

	var state = document.getElementById("state").value;
	//var message = "";
	var flag = true;
	
	if (name_len < 4 || name_len > 50 ){
		document.getElementById("name_error").innerHTML = "<font color=red size=3>Invalid Name</font>";
		//request.setAttribute("NameErrorMessage", );
		flag = false;
	}
	
	if (address_len < 4 || address_len > 50 ){
		document.getElementById("address_error").innerHTML = "<font color=red size=3>Invalid Address</font>";
		flag = false;
	}
	
	if (!isSSNValid || ssn_len != 11 ){
		document.getElementById("ssn_error").innerHTML = "<font color=red size=3>Invalid SSN</font>";
		flag = false;
	}
	
	if ( city_len < 3 || city_len > 50 ){
		document.getElementById("city_error").innerHTML = "<font color=red size=3>Invalid City Name</font>";
	    flag = false;
	}	
	
	if (state == "  "){
		document.getElementById("state_error").innerHTML = "<font color=red size=3>Please select one of the states from the list</font>";
		flag = false;
	}
	
	var email = document.getElementById("email").value;
	var email_len = email.length;
	//var isEmailValid = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$/.test(email);	
	var isEmailValid = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email);
	var zipcode = document.getElementById("zipcode").value;
	var zipcode_len = zipcode.length;
	var isZipcodeValid = /^[0-9][0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]$/.test(zipcode);	
	
	if (!isEmailValid || email_len < 7 ){
		document.getElementById("email_error").innerHTML = "<font color=red size=3>Invalid Email Address</font>";
		flag = false;
	}

	if (!isZipcodeValid || zipcode_len != 10 ){
		document.getElementById("zipcode_error").innerHTML = "<font color=red size=3>Invalid zipcode</font>";
		flag = false;
	}

	if (flag == false){
		//alert(message);
		document.getElementById("form_data").action = "GetFormData.jsp";
		//document.form_data.action = "GetFormData.jsp";
		return false;
	}
	
	document.getElementById("form_data").action = "ValidateFormData";
	document.getElementById("form_data").submit();
	return true;
}